# Exercises
![Exercises 3](https://user-images.githubusercontent.com/70604577/229873364-af350899-70b3-4d53-89f1-101a4f3fda52.png)
![Exercises 3 2](https://user-images.githubusercontent.com/70604577/229873360-93d2a82e-af5f-4aaf-aace-659b51f24939.png)
![Exercises 3 3](https://user-images.githubusercontent.com/70604577/229873362-b036c5b0-602d-4d61-9290-77be0b6c073a.png)
