![Exercises 14 1](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/b2e23fde-6f51-4ca2-9867-e75116940214)

![Exercises 14 2](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/5fb61ba3-5493-4fca-bf68-fdb452de7ed7)

![Exercises 14 3](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/02a0c320-5562-4d0d-ada8-948187622c3e)

![Exercises 14 4](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/55799341-f077-4e60-816c-0e7022d14b5a)

![Exercises 14 5](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/164b6b41-5977-4e66-923c-c4096a1ae106)

![Exercises 14 6](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/6cbc6b1f-61e4-426a-aea5-d18d66cb97fa)
