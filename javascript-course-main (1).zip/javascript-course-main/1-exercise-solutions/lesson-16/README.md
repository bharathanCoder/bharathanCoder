![Exercises 16 1](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/0d6d86b3-3eb6-47b9-a4c7-c5bf61e15898)

![Exercises 16 2](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/21d49ce0-08ec-43cc-a763-0b6e1f1251e9)

![Exercises 16 3](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/ebbd93dd-5bbb-4894-824b-4e8ea94ec1b0)

![Exercises 16 4](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/3a0dbd30-de8e-4e1b-9c47-a7437d53e9a7)

![Exercises 16 5](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/fab792ee-5bcc-4208-9f7a-b4139064d596)

![Exercises 16 6](https://github.com/SuperSimpleDev/javascript-course/assets/70604577/932aa906-3465-4586-9024-e145c212582b)
