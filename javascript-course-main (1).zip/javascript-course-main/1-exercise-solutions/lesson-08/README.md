# Exercises
![Exercises 8](https://user-images.githubusercontent.com/70604577/229874144-fc148193-4e66-4312-9b6b-46e431b6dbf9.png)
![Exercises 8 2](https://user-images.githubusercontent.com/70604577/229874138-1d9f2261-00c2-4a41-9dff-dd33e49a450d.png)
![Exercises 8 3](https://user-images.githubusercontent.com/70604577/229874142-74a004c6-db7a-487e-9ab0-f7b2e45554a9.png)
