# Exercises
![Exercises 9-final](https://user-images.githubusercontent.com/70604577/229875491-f86ea15b-a04f-4ccd-b253-d5dec831528f.png)
![Exercises 9 2-final](https://user-images.githubusercontent.com/70604577/229875495-a7f86dda-952b-4a03-970d-a3b96a8bcc10.png)
![Exercises 9 3-final](https://user-images.githubusercontent.com/70604577/229875499-1cb39540-f487-437d-93b1-ce93926ecc87.png)
![Exercises 9 4-final](https://user-images.githubusercontent.com/70604577/229875502-cd74a8be-25e0-49cc-ab80-70a15e77b0a9.png)
