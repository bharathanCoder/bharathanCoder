Here are the links mentioned in the JavaScript Course:

### Lesson 1 - 12
HTML CSS Full course: https://youtu.be/G3e-cpL7ofc

A.I. tool for searching for code: https://chat.openai.com/chat

### Lesson 13
Starting code for the Amazon project: https://github.com/SuperSimpleDev/javascript-amazon-project

Git installation instructions: https://git-scm.com/downloads

Git and GitHub Full Course: https://youtu.be/hrTQipWp6co

### Lesson 15
Hello external library: https://unpkg.com/supersimpledev@1.0.1/hello.js

DayJS external library: https://unpkg.com/dayjs@1.11.10/dayjs.min.js

Hello (ESM version): https://unpkg.com/supersimpledev@1.0.1/hello.esm.js

DayJS (ESM version): https://unpkg.com/supersimpledev@8.5.0/dayjs/esm/index.js

How to Put a Website on the Internet: https://youtu.be/p1QU3kLFPdg

### Lesson 16
Jasmine Testing Framework: https://github.com/jasmine/jasmine/releases/tag/v5.1.1

Jasmine Documentation: https://jasmine.github.io/api/5.1/global

### Lesson 17
Clothing size chart image: https://supersimple.dev/images/clothing-size-chart.png

Appliance instructions image: https://supersimple.dev/images/appliance-instructions.png

Appliance warranty image: https://supersimple.dev/images/appliance-warranty.png

### Lesson 18
SuperSimpleBackendDev documentation: https://supersimplebackend.dev/documentation

Put a Website on the Internet: https://youtu.be/p1QU3kLFPdg
